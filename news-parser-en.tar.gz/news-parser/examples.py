"""
Приклади використання News Parser
"""

from news_parser import NewsParser, NewsArticle
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def example_1_basic_parsing():
    """Приклад 1: Базовий парсинг"""
    print("\n=== Приклад 1: Базовий парсинг ===")
    
    parser = NewsParser()
    
    # Парсимо Hacker News
    articles = parser.parse_hacker_news(max_articles=10)
    parser.add_articles(articles)
    
    # Експорт
    parser.export_to_csv("example1.csv")
    parser.export_to_json("example1.json")
    
    print(f"✅ Зібрано {len(articles)} статей")


def example_2_multiple_sources():
    """Приклад 2: Збір з декількох джерел"""
    print("\n=== Приклад 2: Декілька джерел ===")
    
    parser = NewsParser()
    
    # Hacker News
    hn = parser.parse_hacker_news(max_articles=15)
    parser.add_articles(hn)
    print(f"Hacker News: {len(hn)} статей")
    
    # BBC Technology
    bbc = parser.parse_bbc_news(category="technology", max_articles=10)
    parser.add_articles(bbc)
    print(f"BBC Tech: {len(bbc)} статей")
    
    # Статистика
    stats = parser.get_statistics()
    print(f"\nВсього: {stats['total']} статей")
    print(f"Джерела: {stats['sources']}")
    
    # Експорт
    parser.export_to_csv("multiple_sources.csv")
    parser.export_to_html("multiple_sources.html")


def example_3_keyword_filtering():
    """Приклад 3: Фільтрація по ключовим словам"""
    print("\n=== Приклад 3: Фільтрація ===")
    
    parser = NewsParser()
    
    # Збираємо новини
    articles = parser.parse_hacker_news(max_articles=30)
    parser.add_articles(articles)
    
    # Фільтруємо по ключовим словам
    keywords = ["AI", "Python", "machine learning"]
    filtered = parser.filter_by_keywords(keywords)
    
    print(f"Всього статей: {len(articles)}")
    print(f"Після фільтрації: {len(filtered)}")
    print(f"Ключові слова: {keywords}")
    
    # Експорт відфільтрованих
    parser.export_to_csv("filtered_ai_python.csv", filtered)
    parser.export_to_json("filtered_ai_python.json", filtered)
    
    # Показуємо декілька заголовків
    print("\nПерші 5 відфільтрованих статей:")
    for i, article in enumerate(filtered[:5], 1):
        print(f"{i}. {article.title}")


def example_4_custom_site():
    """Приклад 4: Парсинг кастомного сайту"""
    print("\n=== Приклад 4: Кастомний сайт ===")
    
    parser = NewsParser()
    
    # Можна спробувати будь-який новинний сайт
    urls = [
        "https://news.ycombinator.com/",
        "https://www.bbc.com/news/technology"
    ]
    
    for url in urls:
        articles = parser.parse_generic_news(url, max_articles=10)
        parser.add_articles(articles)
        print(f"{url}: {len(articles)} статей")
    
    parser.export_to_csv("custom_sites.csv")


def example_5_html_export():
    """Приклад 5: Експорт в HTML для перегляду"""
    print("\n=== Приклад 5: HTML експорт ===")
    
    parser = NewsParser()
    
    # Збираємо новини
    hn = parser.parse_hacker_news(max_articles=20)
    bbc = parser.parse_bbc_news(max_articles=15)
    
    parser.add_articles(hn)
    parser.add_articles(bbc)
    
    # Експортуємо в красивий HTML
    parser.export_to_html("news_report.html")
    
    print(f"✅ Створено HTML звіт з {len(parser.articles)} статтями")
    print("Відкрийте news_report.html у браузері")


def example_6_statistics():
    """Приклад 6: Статистика"""
    print("\n=== Приклад 6: Статистика ===")
    
    parser = NewsParser()
    
    # Збираємо з різних джерел
    parser.add_articles(parser.parse_hacker_news(max_articles=25))
    parser.add_articles(parser.parse_bbc_news("technology", max_articles=20))
    parser.add_articles(parser.parse_bbc_news("business", max_articles=15))
    
    # Отримуємо статистику
    stats = parser.get_statistics()
    
    print(f"Загальна кількість: {stats['total']}")
    print("\nПо джерелах:")
    for source, count in stats['sources'].items():
        print(f"  - {source}: {count}")
    
    print("\nПо категоріях:")
    for category, count in stats['categories'].items():
        print(f"  - {category}: {count}")


def run_all_examples():
    """Запускає всі приклади"""
    examples = [
        example_1_basic_parsing,
        example_2_multiple_sources,
        example_3_keyword_filtering,
        example_4_custom_site,
        example_5_html_export,
        example_6_statistics
    ]
    
    for example in examples:
        try:
            example()
        except Exception as e:
            logger.error(f"Помилка в {example.__name__}: {e}")
        print("\n" + "="*60)


if __name__ == "__main__":
    run_all_examples()
