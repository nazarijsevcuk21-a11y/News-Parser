# 🎯 Технічні навички - News Parser

## Використані технології та демонстрація навичок

### 📚 Core Technologies

#### Python 3.8+
- Web scraping
- HTTP requests
- HTML parsing
- Regular expressions
- OOP design
- Type hints
- Error handling

#### requests
- HTTP/HTTPS запити
- Session management
- Custom headers (User-Agent)
- Timeout handling
- Response status codes

#### BeautifulSoup4
- HTML/XML парсинг
- CSS селектори
- Навігація по DOM дереву
- Витягування тексту та атрибутів
- Робота з різними парсерами (lxml, html.parser)

#### Regular Expressions
- Пошук паттернів
- Валідація URL
- Витягування дат
- Текстовий аналіз

---

## 💻 Демонстрація навичок у коді

### 1. Web Scraping з requests

```python
class NewsParser:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def parse_generic_news(self, url: str, max_articles: int = 20):
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()  # Перевірка статусу
            
            soup = BeautifulSoup(response.content, 'html.parser')
            # Парсинг...
            
        except requests.RequestException as e:
            logger.error(f"Request error: {e}")
            return []
```

**Демонструє:**
- Session для збереження cookies
- Custom User-Agent для коректної роботи
- Timeout для уникнення зависання
- Exception handling для мережевих помилок
- raise_for_status() для перевірки HTTP статусу

### 2. BeautifulSoup парсинг

```python
def _extract_article_info(self, element, base_url: str):
    """Універсальне витягування інформації про статтю"""
    
    # Шукаємо заголовок (пробуємо різні теги)
    title_tag = element.find(['h1', 'h2', 'h3', 'h4', 'a'])
    title = title_tag.get_text(strip=True)
    
    # Шукаємо посилання
    link_tag = element.find('a', href=True)
    url = urljoin(base_url, link_tag['href']) if link_tag else base_url
    
    # Шукаємо опис
    desc_tag = element.find(['p', 'div.description', 'div.excerpt'])
    description = desc_tag.get_text(strip=True)[:200] if desc_tag else ""
    
    # Шукаємо дату
    date_tag = element.find(['time', 'span.date', 'div.date'])
    date_str = date_tag.get('datetime') or date_tag.get_text(strip=True)
    
    return NewsArticle(title=title, url=url, description=description, date=date_str)
```

**Демонструє:**
- Множинні селектори (find(['h1', 'h2', ...]))
- CSS класи (div.description)
- Витягування атрибутів (get('datetime'))
- get_text(strip=True) для очищення тексту
- urljoin для абсолютних URL
- Обробка None випадків

### 3. CSS селектори

```python
def parse_hacker_news(self, max_articles: int = 30):
    """Парсер з CSS селекторами"""
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # CSS селектор для статей
    items = soup.select('tr.athing')[:max_articles]
    
    for item in items:
        # Складний селектор з вкладеністю
        title_tag = item.select_one('span.titleline > a')
        
        if not title_tag:
            continue
        
        title = title_tag.get_text(strip=True)
        article_url = title_tag.get('href', '')
```

**Демонструє:**
- select() для множинних елементів
- select_one() для одного елемента
- CSS класи (tr.athing)
- Селектори з вкладеністю (span.titleline > a)
- Slicing [:max_articles]

### 4. Універсальний парсер

```python
def parse_generic_news(self, url: str, max_articles: int = 20):
    """Адаптивний парсинг для різних сайтів"""
    
    # Пробуємо різні селектори
    article_selectors = [
        'article',
        'div.article',
        'div.news-item',
        'div.post',
        'div[class*="article"]',  # Частковий match
        'div[class*="news"]',
        'li.news-item',
        'div.story'
    ]
    
    # Знаходимо перший що спрацює
    for selector in article_selectors:
        items = soup.select(selector)
        if items:
            logger.info(f"Used selector: {selector}")
            break
    
    # Fallback якщо нічого не знайдено
    if not items:
        items = soup.find_all(['article', 'div'], limit=max_articles)
```

**Демонструє:**
- Множинні стратегії парсингу
- Атрибутні селектори [class*="article"]
- Fallback логіка
- Адаптивність до різних структур

### 5. OOP Design

```python
class NewsArticle:
    """Інкапсуляція даних статті"""
    
    def __init__(self, title: str, url: str, description: str = "", 
                 date: str = "", category: str = "", source: str = ""):
        self.title = title
        self.url = url
        self.description = description
        self.date = date or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.category = category
        self.source = source
    
    def to_dict(self) -> Dict:
        """Серіалізація в словник"""
        return {
            'title': self.title,
            'url': self.url,
            'description': self.description,
            'date': self.date,
            'category': self.category,
            'source': self.source
        }
    
    def matches_keywords(self, keywords: List[str]) -> bool:
        """Бізнес-логіка фільтрації"""
        if not keywords:
            return True
        
        text = f"{self.title} {self.description}".lower()
        return any(keyword.lower() in text for keyword in keywords)
```

**Демонструє:**
- Class design з чіткою відповідальністю
- Default values в __init__
- Type hints для всіх параметрів
- Методи трансформації даних (to_dict)
- Бізнес-логіка в методах класу

### 6. Фільтрація та пошук

```python
def filter_by_keywords(self, keywords: List[str]) -> List[NewsArticle]:
    """Фільтрація з логуванням"""
    if not keywords:
        return self.articles
    
    # List comprehension з методом класу
    filtered = [article for article in self.articles 
               if article.matches_keywords(keywords)]
    
    logger.info(f"Filtered: {len(filtered)} out of {len(self.articles)}")
    return filtered

def matches_keywords(self, keywords: List[str]) -> bool:
    """Регістронезалежний пошук"""
    text = f"{self.title} {self.description}".lower()
    
    # any() з generator expression
    return any(keyword.lower() in text for keyword in keywords)
```

**Демонструє:**
- List comprehension
- Generator expressions з any()
- Регістронезалежний пошук (.lower())
- Комбінація полів для пошуку
- Логування результатів

### 7. Експорт даних

```python
def export_to_csv(self, filename: str, articles: List[NewsArticle] = None):
    """CSV експорт з правильним encoding"""
    articles = articles or self.articles
    
    filepath = self.output_dir / filename
    
    with open(filepath, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=[
            'title', 'url', 'description', 'date', 'category', 'source'
        ])
        writer.writeheader()
        writer.writerows([article.to_dict() for article in articles])
    
    logger.info(f"Exported {len(articles)} articles to {filepath}")

def export_to_json(self, filename: str, articles: List[NewsArticle] = None):
    """JSON з метаданими"""
    data = {
        'total': len(articles),
        'timestamp': datetime.now().isoformat(),
        'articles': [article.to_dict() for article in articles]
    }
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
```

**Демонструє:**
- csv.DictWriter для структурованих даних
- encoding='utf-8' для кирилиці
- newline='' для CSV
- ensure_ascii=False для JSON
- indent=2 для читабельності JSON
- Метадані в експорті (timestamp, total)

### 8. HTML генерація

```python
def export_to_html(self, filename: str, articles: List[NewsArticle] = None):
    """Генерація HTML зі стилями"""
    
    html_content = """
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новини</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 0 auto; }
        .article { border-bottom: 1px solid #ddd; padding: 20px 0; }
        .article a { color: #0066cc; text-decoration: none; }
    </style>
</head>
<body>
    <h1>Новини</h1>
""".format(total=len(articles))
    
    for article in articles:
        html_content += f"""
    <div class="article">
        <h2><a href="{article.url}" target="_blank">{article.title}</a></h2>
        <div class="meta">{article.source} | {article.date}</div>
        <p>{article.description}</p>
    </div>
"""
```

**Демонструє:**
- String formatting з .format()
- f-strings для вставки змінних
- HTML5 структура
- Responsive meta tags
- CSS styling
- Target="_blank" для нових вкладок

### 9. URL обробка

```python
from urllib.parse import urljoin, urlparse

# Перетворення відносних URL в абсолютні
url = urljoin(base_url, link_tag['href'])

# Витягування домену
source = urlparse(base_url).netloc
# https://www.bbc.com/news -> www.bbc.com
```

**Демонструє:**
- urljoin для абсолютних посилань
- urlparse для розбору URL
- Робота з різними типами URL

### 10. Error Handling

```python
def parse_generic_news(self, url: str, max_articles: int = 20):
    try:
        response = self.session.get(url, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        # Парсинг...
        
    except requests.RequestException as e:
        logger.error(f"Request error: {e}")
        return []
    except Exception as e:
        logger.error(f"Parse error: {e}")
        return []

def _extract_article_info(self, element, base_url: str):
    try:
        # Витягування даних
        return NewsArticle(...)
    except Exception as e:
        logger.debug(f"Failed to extract: {e}")
        return None
```

**Демонструє:**
- Специфічні exception типи (RequestException)
- Загальний Exception як fallback
- Логування на різних рівнях (error, debug)
- Graceful degradation (return [] замість crash)
- Optional return types

---

## 🏗 Архітектурні паттерни

### 1. Single Responsibility

Кожен клас має одну чітку відповідальність:
- `NewsArticle` - представлення даних
- `NewsParser` - парсинг та експорт

### 2. Strategy Pattern

```python
# Різні стратегії парсингу
parser.parse_hacker_news()
parser.parse_bbc_news()
parser.parse_generic_news()
```

### 3. Builder Pattern

```python
parser = NewsParser()
parser.add_articles(hn_articles)
parser.add_articles(bbc_articles)
parser.export_to_csv("combined.csv")
```

### 4. Factory Pattern

```python
# NewsArticle створюється в різних методах
article = NewsArticle(title=..., url=..., source=...)
```

---

## 📊 Regular Expressions (потенціал)

```python
import re

# Витягування дат з тексту
date_pattern = r'\d{4}-\d{2}-\d{2}'
dates = re.findall(date_pattern, text)

# Очищення HTML тегів
clean_text = re.sub(r'<[^>]+>', '', html_text)

# Пошук email
email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
emails = re.findall(email_pattern, text)

# Валідація URL
url_pattern = r'^https?://[^\s]+$'
is_valid = re.match(url_pattern, url)
```

---

## 💡 Best Practices

### 1. User-Agent

```python
# Коректний User-Agent для уникнення блокування
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}
```

### 2. Timeout

```python
# Завжди вказуємо timeout
response = requests.get(url, timeout=10)
```

### 3. Encoding

```python
# UTF-8 для кирилиці
with open(file, 'w', encoding='utf-8') as f:
    f.write(content)
```

### 4. Logging

```python
# Логування замість print
logger.info("Success")
logger.warning("Warning")
logger.error("Error")
logger.debug("Debug info")
```

### 5. Type Hints

```python
def parse_news(url: str, max_articles: int = 20) -> List[NewsArticle]:
    """Завжди вказуємо типи"""
    pass
```

---

## 🚀 Web Scraping Best Practices

### 1. Поважайте robots.txt

```python
# Перевіряйте перед парсингом
# https://example.com/robots.txt
```

### 2. Rate Limiting

```python
import time

for url in urls:
    articles = parser.parse_generic_news(url)
    time.sleep(1)  # Пауза між запитами
```

### 3. Caching

```python
from functools import lru_cache

@lru_cache(maxsize=100)
def get_page(url: str):
    return requests.get(url)
```

### 4. Error Recovery

```python
# Retry логіка
for attempt in range(3):
    try:
        response = requests.get(url)
        break
    except:
        if attempt == 2:
            raise
        time.sleep(2)
```

---

## 📈 Продуктивність

### Асинхронний парсинг (розширення)

```python
import asyncio
import aiohttp

async def fetch_async(url):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()

# Паралельний збір з декількох джерел
urls = ['url1', 'url2', 'url3']
results = await asyncio.gather(*[fetch_async(url) for url in urls])
```

---

## 💼 Для портфоліо

**Що демонструє цей проект:**

✅ **Технічні навички:**
- Web scraping
- HTTP requests
- HTML parsing
- Data processing
- File I/O

✅ **Розуміння best practices:**
- Error handling
- Logging
- Type hints
- Clean code
- Documentation

✅ **Практичні навички:**
- Реальний use case
- Множинні формати експорту
- Адаптивний парсинг
- Фільтрація даних

✅ **Soft skills:**
- User-friendly interface
- Comprehensive docs
- Examples included
- Professional structure

---

## 📊 Метрики проекту

- **Lines of Code:** ~400
- **Classes:** 2
- **Methods:** 15+
- **Supported formats:** 3 (CSV, JSON, HTML)
- **News sources:** 2+ (extensible)
- **Documentation:** 500+ lines

Проект демонструє всі ключові навички web scraping та data processing!
