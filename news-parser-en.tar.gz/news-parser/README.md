# 📰 News Parser - Парсер новин

Потужний інструмент для збору та аналізу новин з веб-сайтів з підтримкою фільтрації та експорту в різні формати.

## ✨ Можливості

### 🌐 Парсинг
- Збір новин з популярних сайтів (Hacker News, BBC News)
- Універсальний парсер для будь-яких новинних сайтів
- Автоматичне визначення структури сторінки
- Підтримка множинних джерел одночасно

### 🔍 Фільтрація
- Фільтрація по ключовим словам
- Пошук в заголовках та описах
- Регістронезалежний пошук
- Множинні ключові слова

### 💾 Експорт
- **CSV** - для аналізу в Excel/Google Sheets
- **JSON** - для інтеграції з іншими програмами
- **HTML** - красивий веб-звіт для перегляду

### 📊 Аналіз
- Статистика по джерелах
- Статистика по категоріях
- Підрахунок загальної кількості

## 🛠 Технології

- **Python 3.8+**
- **requests** - HTTP запити
- **BeautifulSoup4** - парсинг HTML
- **lxml** - швидкий парсер
- **Regular Expressions** - пошук паттернів

## 📦 Встановлення

### 1. Клонуйте репозиторій

```bash
git clone https://github.com/yourusername/news-parser.git
cd news-parser
```

### 2. Встановіть залежності

```bash
pip install -r requirements.txt
```

### 3. Запустіть

```bash
python news_parser.py
```

## 🚀 Швидкий старт

### Базове використання

```python
from news_parser import NewsParser

# Створюємо парсер
parser = NewsParser()

# Збираємо новини з Hacker News
articles = parser.parse_hacker_news(max_articles=20)
parser.add_articles(articles)

# Експортуємо в CSV
parser.export_to_csv("news.csv")
```

### З фільтрацією

```python
from news_parser import NewsParser

parser = NewsParser()

# Збираємо новини
articles = parser.parse_hacker_news(max_articles=30)
parser.add_articles(articles)

# Фільтруємо по ключовим словам
keywords = ["AI", "Python", "machine learning"]
filtered = parser.filter_by_keywords(keywords)

# Експортуємо відфільтровані
parser.export_to_csv("ai_news.csv", filtered)
parser.export_to_json("ai_news.json", filtered)
```

### Декілька джерел

```python
from news_parser import NewsParser

parser = NewsParser()

# Hacker News
hn_articles = parser.parse_hacker_news(max_articles=20)
parser.add_articles(hn_articles)

# BBC Technology
bbc_articles = parser.parse_bbc_news(category="technology", max_articles=15)
parser.add_articles(bbc_articles)

# BBC Business
business_articles = parser.parse_bbc_news(category="business", max_articles=10)
parser.add_articles(business_articles)

# Експорт всіх
parser.export_to_html("all_news.html")

# Статистика
stats = parser.get_statistics()
print(f"Всього: {stats['total']} статей")
print(f"Джерела: {stats['sources']}")
```

## 📚 API Reference

### NewsParser

#### `__init__(output_dir="output")`
Ініціалізує парсер з вказаною папкою для вихідних файлів.

#### `parse_hacker_news(max_articles=30)`
Парсить новини з Hacker News.

**Параметри:**
- `max_articles` (int) - максимальна кількість статей

**Повертає:** `List[NewsArticle]`

#### `parse_bbc_news(category="technology", max_articles=20)`
Парсить новини з BBC News.

**Параметри:**
- `category` (str) - категорія новин (technology, business, science)
- `max_articles` (int) - максимальна кількість

**Повертає:** `List[NewsArticle]`

#### `parse_generic_news(url, max_articles=20)`
Універсальний парсер для будь-якого новинного сайту.

**Параметри:**
- `url` (str) - URL сайту
- `max_articles` (int) - максимальна кількість

**Повертає:** `List[NewsArticle]`

#### `filter_by_keywords(keywords)`
Фільтрує статті по ключовим словам.

**Параметри:**
- `keywords` (List[str]) - список ключових слів

**Повертає:** `List[NewsArticle]`

#### `export_to_csv(filename, articles=None)`
Експортує статті в CSV файл.

#### `export_to_json(filename, articles=None)`
Експортує статті в JSON файл.

#### `export_to_html(filename, articles=None)`
Експортує статті в HTML файл.

#### `get_statistics()`
Повертає статистику по зібраним статтям.

**Повертає:** `Dict` з ключами: `total`, `sources`, `categories`

### NewsArticle

Клас для представлення новинної статті.

**Атрибути:**
- `title` (str) - заголовок
- `url` (str) - посилання
- `description` (str) - опис
- `date` (str) - дата публікації
- `category` (str) - категорія
- `source` (str) - джерело

**Методи:**
- `to_dict()` - конвертує в словник
- `matches_keywords(keywords)` - перевіряє наявність ключових слів

## 📝 Приклади

### Приклад 1: Збір та експорт

```python
parser = NewsParser()

# Збираємо новини
articles = parser.parse_hacker_news(max_articles=25)
parser.add_articles(articles)

# Експортуємо в різні формати
parser.export_to_csv("hacker_news.csv")
parser.export_to_json("hacker_news.json")
parser.export_to_html("hacker_news.html")
```

### Приклад 2: Фільтрація по темах

```python
parser = NewsParser()

# Збираємо з BBC
tech_news = parser.parse_bbc_news("technology", max_articles=30)
parser.add_articles(tech_news)

# Фільтруємо тільки про AI
ai_keywords = ["artificial intelligence", "AI", "machine learning", "neural"]
ai_news = parser.filter_by_keywords(ai_keywords)

print(f"Знайдено {len(ai_news)} статей про AI")
parser.export_to_csv("ai_articles.csv", ai_news)
```

### Приклад 3: Моніторинг конкретних тем

```python
parser = NewsParser()

# Збираємо з різних джерел
parser.add_articles(parser.parse_hacker_news(max_articles=30))
parser.add_articles(parser.parse_bbc_news("technology", max_articles=20))

# Шукаємо конкретні теми
python_news = parser.filter_by_keywords(["Python", "Django", "Flask"])
security_news = parser.filter_by_keywords(["security", "vulnerability", "hack"])

# Окремі звіти
parser.export_to_csv("python_news.csv", python_news)
parser.export_to_csv("security_news.csv", security_news)
```

### Приклад 4: Щоденний дайджест

```python
from datetime import datetime

parser = NewsParser()

# Збираємо новини з усіх джерел
parser.add_articles(parser.parse_hacker_news(max_articles=20))
parser.add_articles(parser.parse_bbc_news("technology", max_articles=15))
parser.add_articles(parser.parse_bbc_news("business", max_articles=10))

# Створюємо дайджест
date_str = datetime.now().strftime("%Y-%m-%d")
parser.export_to_html(f"daily_digest_{date_str}.html")
parser.export_to_json(f"daily_digest_{date_str}.json")

print(f"✅ Дайджест за {date_str} створено!")
```

## 📁 Структура проекту

```
news-parser/
│
├── news_parser.py          # Основний модуль
├── examples.py             # Приклади використання
├── requirements.txt        # Залежності
├── README.md              # Документація
│
└── output/                # Вихідні файли (створюється автоматично)
    ├── news.csv
    ├── news.json
    └── news.html
```

## 🎯 Use Cases

### 1. Моніторинг новин у своїй галузі

```python
# Щоденний збір новин про Python
parser = NewsParser()
articles = parser.parse_hacker_news(max_articles=50)
parser.add_articles(articles)

python_news = parser.filter_by_keywords(["Python", "Django", "FastAPI"])
parser.export_to_csv(f"python_news_{datetime.now().date()}.csv", python_news)
```

### 2. Конкурентний аналіз

```python
# Моніторинг новин про конкурентів
competitors = ["OpenAI", "Google AI", "Microsoft AI"]
articles = parser.parse_bbc_news("technology", max_articles=50)
parser.add_articles(articles)

for company in competitors:
    company_news = parser.filter_by_keywords([company])
    parser.export_to_csv(f"{company}_news.csv", company_news)
```

### 3. Дослідження трендів

```python
# Збір новин за темами
topics = {
    "AI": ["artificial intelligence", "machine learning", "neural network"],
    "Crypto": ["bitcoin", "cryptocurrency", "blockchain"],
    "Climate": ["climate change", "global warming", "renewable energy"]
}

parser = NewsParser()
parser.add_articles(parser.parse_hacker_news(max_articles=100))

for topic_name, keywords in topics.items():
    topic_news = parser.filter_by_keywords(keywords)
    print(f"{topic_name}: {len(topic_news)} статей")
    parser.export_to_csv(f"{topic_name}_trends.csv", topic_news)
```

## 🔧 Розширення

### Додавання нового джерела

```python
def parse_custom_site(self, url: str, max_articles: int = 20):
    """Парсер для вашого сайту"""
    response = self.session.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    
    articles = []
    items = soup.select('your.selector')
    
    for item in items[:max_articles]:
        title = item.select_one('h2').get_text(strip=True)
        link = item.select_one('a')['href']
        
        article = NewsArticle(title=title, url=link, source="Custom Site")
        articles.append(article)
    
    return articles
```

### Додавання фільтрів

```python
def filter_by_date(self, date_str: str):
    """Фільтрація по даті"""
    return [a for a in self.articles if date_str in a.date]

def filter_by_source(self, source: str):
    """Фільтрація по джерелу"""
    return [a for a in self.articles if source in a.source]
```

## 🚨 Обмеження та зауваження

### Rate Limiting
Деякі сайти можуть обмежувати кількість запитів. Додайте затримку:

```python
import time

for url in urls:
    articles = parser.parse_generic_news(url)
    time.sleep(2)  # Пауза 2 секунди
```

### Robots.txt
Завжди перевіряйте robots.txt сайту перед парсингом:
```
https://example.com/robots.txt
```

### User-Agent
Парсер використовує стандартний User-Agent браузера для коректної роботи.

## 📊 Формати експорту

### CSV
```csv
title,url,description,date,category,source
"News Title","https://...",""Description","2024-11-24","Tech","BBC News"
```

### JSON
```json
{
  "total": 20,
  "timestamp": "2024-11-24T10:30:00",
  "articles": [
    {
      "title": "News Title",
      "url": "https://...",
      "description": "Description",
      "date": "2024-11-24",
      "category": "Tech",
      "source": "BBC News"
    }
  ]
}
```

### HTML
Красивий HTML документ з всіма статтями, стилізований CSS.

## 🤝 Внесок

1. Fork репозиторій
2. Створіть гілку: `git checkout -b feature/NewSource`
3. Commit: `git commit -m 'Add new news source'`
4. Push: `git push origin feature/NewSource`
5. Відкрийте Pull Request

## 📄 Ліцензія

MIT License - дивіться [LICENSE](LICENSE)

## 👤 Автор

Ваше ім'я - [@your_username](https://github.com/your_username)

## 🙏 Подяки

- [requests](https://requests.readthedocs.io/) - HTTP бібліотека
- [BeautifulSoup](https://www.crummy.com/software/BeautifulSoup/) - HTML парсер
- [lxml](https://lxml.de/) - швидкий XML/HTML парсер

---

⭐️ Якщо проект корисний, поставте зірочку на GitHub!
