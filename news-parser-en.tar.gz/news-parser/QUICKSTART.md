# 🚀 Швидкий старт - News Parser

## За 3 хвилини до перших новин!

### Крок 1: Встановлення (30 сек)

```bash
pip install -r requirements.txt
```

### Крок 2: Запуск (30 сек)

```bash
python news_parser.py
```

Готово! Парсер:
- Зібрав новини з Hacker News
- Зібрав новини з BBC Technology
- Створив файли в папці `output/`:
  - `all_news.csv` - всі новини
  - `all_news.json` - у форматі JSON
  - `all_news.html` - HTML звіт
  - `filtered_news.csv` - відфільтровані по ключовим словам

### Крок 3: Перегляд результатів

Відкрийте `output/all_news.html` у браузері для красивого перегляду.

---

## 💡 Швидкі приклади

### Збір новин про AI

```python
from news_parser import NewsParser

parser = NewsParser()
articles = parser.parse_hacker_news(max_articles=30)
parser.add_articles(articles)

ai_news = parser.filter_by_keywords(["AI", "artificial intelligence"])
parser.export_to_csv("ai_news.csv", ai_news)
```

### Множинні джерела

```python
parser = NewsParser()

# Hacker News
parser.add_articles(parser.parse_hacker_news(20))

# BBC
parser.add_articles(parser.parse_bbc_news("technology", 15))

# Експорт
parser.export_to_html("tech_news.html")
```

### Моніторинг теми

```python
parser = NewsParser()

# Збираємо новини
parser.add_articles(parser.parse_hacker_news(50))

# Фільтруємо по темах
python_news = parser.filter_by_keywords(["Python", "Django"])
crypto_news = parser.filter_by_keywords(["Bitcoin", "crypto"])

# Окремі файли
parser.export_to_csv("python.csv", python_news)
parser.export_to_csv("crypto.csv", crypto_news)
```

---

## 🎯 Що далі?

### Запустити приклади

```bash
python examples.py
```

Побачите 6 різних сценаріїв використання.

### Читати документацію

Дивіться [README.md](README.md) для повної документації.

### Додати своє джерело

```python
# У news_parser.py додайте метод:
def parse_my_site(self, url: str):
    # Ваш код парсингу
    pass
```

---

## ❓ Проблеми?

**Помилка імпорту:**
```bash
pip install requests beautifulsoup4 lxml
```

**Немає папки output:**
Вона створюється автоматично при першому запуску.

**Сайт не парситься:**
Спробуйте `parse_generic_news(url)` для універсального парсингу.

---

**Готово!** Тепер у вас є працюючий парсер новин 🎉
