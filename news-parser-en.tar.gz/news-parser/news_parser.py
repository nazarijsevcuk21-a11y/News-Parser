"""
News Parser - Парсер новин з веб-сайтів
Збирає новини, фільтрує по ключовим словам, експортує в CSV/JSON
"""

import requests
from bs4 import BeautifulSoup
import csv
import json
import re
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional
import logging
from urllib.parse import urljoin, urlparse
import time

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class NewsArticle:
    """Клас для представлення статті новини"""
    
    def __init__(self, title: str, url: str, description: str = "", 
                 date: str = "", category: str = "", source: str = ""):
        self.title = title
        self.url = url
        self.description = description
        self.date = date or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.category = category
        self.source = source
    
    def to_dict(self) -> Dict:
        """Конвертує в словник"""
        return {
            'title': self.title,
            'url': self.url,
            'description': self.description,
            'date': self.date,
            'category': self.category,
            'source': self.source
        }
    
    def matches_keywords(self, keywords: List[str]) -> bool:
        """Перевіряє чи стаття містить ключові слова"""
        if not keywords:
            return True
        
        text = f"{self.title} {self.description}".lower()
        return any(keyword.lower() in text for keyword in keywords)


class NewsParser:
    """Основний клас для парсингу новин"""
    
    def __init__(self, output_dir: str = "output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.articles = []
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def parse_generic_news(self, url: str, max_articles: int = 20) -> List[NewsArticle]:
        """Універсальний парсер для новинних сайтів"""
        try:
            logger.info(f"Парсинг: {url}")
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            articles = []
            
            # Шукаємо статті за типовими селекторами
            article_selectors = [
                'article',
                'div.article',
                'div.news-item',
                'div.post',
                'div[class*="article"]',
                'div[class*="news"]',
                'li.news-item',
                'div.story'
            ]
            
            for selector in article_selectors:
                items = soup.select(selector)
                if items:
                    logger.info(f"Знайдено {len(items)} статей за селектором: {selector}")
                    break
            
            if not items:
                logger.warning("Не знайдено статей за стандартними селекторами")
                items = soup.find_all(['article', 'div'], limit=max_articles)
            
            for item in items[:max_articles]:
                article = self._extract_article_info(item, url)
                if article and article.title:
                    articles.append(article)
            
            logger.info(f"Зібрано {len(articles)} статей")
            return articles
            
        except requests.RequestException as e:
            logger.error(f"Помилка запиту: {e}")
            return []
        except Exception as e:
            logger.error(f"Помилка парсингу: {e}")
            return []
    
    def _extract_article_info(self, element, base_url: str) -> Optional[NewsArticle]:
        """Витягує інформацію про статтю з HTML елемента"""
        try:
            # Шукаємо заголовок
            title_tag = element.find(['h1', 'h2', 'h3', 'h4', 'a'])
            if not title_tag:
                return None
            
            title = title_tag.get_text(strip=True)
            
            # Шукаємо посилання
            link_tag = element.find('a', href=True)
            url = urljoin(base_url, link_tag['href']) if link_tag else base_url
            
            # Шукаємо опис
            desc_tag = element.find(['p', 'div.description', 'div.excerpt'])
            description = desc_tag.get_text(strip=True)[:200] if desc_tag else ""
            
            # Шукаємо дату
            date_tag = element.find(['time', 'span.date', 'div.date'])
            date_str = ""
            if date_tag:
                date_str = date_tag.get('datetime') or date_tag.get_text(strip=True)
            
            # Джерело
            source = urlparse(base_url).netloc
            
            return NewsArticle(
                title=title,
                url=url,
                description=description,
                date=date_str,
                source=source
            )
            
        except Exception as e:
            logger.debug(f"Не вдалось витягти статтю: {e}")
            return None
    
    def parse_hacker_news(self, max_articles: int = 30) -> List[NewsArticle]:
        """Парсер для Hacker News"""
        url = "https://news.ycombinator.com/"
        try:
            logger.info("Парсинг Hacker News...")
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            articles = []
            items = soup.select('tr.athing')[:max_articles]
            
            for item in items:
                title_tag = item.select_one('span.titleline > a')
                if not title_tag:
                    continue
                
                title = title_tag.get_text(strip=True)
                article_url = title_tag.get('href', '')
                
                if not article_url.startswith('http'):
                    article_url = urljoin(url, article_url)
                
                article = NewsArticle(
                    title=title,
                    url=article_url,
                    category="Tech",
                    source="Hacker News"
                )
                articles.append(article)
            
            logger.info(f"Зібрано {len(articles)} статей з Hacker News")
            return articles
            
        except Exception as e:
            logger.error(f"Помилка парсингу Hacker News: {e}")
            return []
    
    def parse_bbc_news(self, category: str = "technology", max_articles: int = 20) -> List[NewsArticle]:
        """Парсер для BBC News"""
        url = f"https://www.bbc.com/news/{category}"
        try:
            logger.info(f"Парсинг BBC News ({category})...")
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            articles = []
            items = soup.select('div[data-testid="card-text-wrapper"]')[:max_articles]
            
            for item in items:
                title_tag = item.find('h2')
                if not title_tag:
                    continue
                
                title = title_tag.get_text(strip=True)
                
                link_tag = item.find_parent('a', href=True)
                article_url = urljoin(url, link_tag['href']) if link_tag else url
                
                desc_tag = item.find('p')
                description = desc_tag.get_text(strip=True) if desc_tag else ""
                
                article = NewsArticle(
                    title=title,
                    url=article_url,
                    description=description,
                    category=category.capitalize(),
                    source="BBC News"
                )
                articles.append(article)
            
            logger.info(f"Зібрано {len(articles)} статей з BBC News")
            return articles
            
        except Exception as e:
            logger.error(f"Помилка парсингу BBC News: {e}")
            return []
    
    def filter_by_keywords(self, keywords: List[str]) -> List[NewsArticle]:
        """Фільтрує статті по ключовим словам"""
        if not keywords:
            return self.articles
        
        filtered = [article for article in self.articles 
                   if article.matches_keywords(keywords)]
        
        logger.info(f"Відфільтровано: {len(filtered)} з {len(self.articles)} статей")
        return filtered
    
    def filter_by_date_range(self, start_date: str = None, end_date: str = None) -> List[NewsArticle]:
        """Фільтрує статті по діапазону дат"""
        # Заглушка для майбутньої реалізації
        return self.articles
    
    def export_to_csv(self, filename: str = "news.csv", articles: List[NewsArticle] = None):
        """Експортує новини в CSV"""
        articles = articles or self.articles
        if not articles:
            logger.warning("Немає статей для експорту")
            return
        
        filepath = self.output_dir / filename
        
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=[
                'title', 'url', 'description', 'date', 'category', 'source'
            ])
            writer.writeheader()
            writer.writerows([article.to_dict() for article in articles])
        
        logger.info(f"✅ Експортовано {len(articles)} статей в {filepath}")
    
    def export_to_json(self, filename: str = "news.json", articles: List[NewsArticle] = None):
        """Експортує новини в JSON"""
        articles = articles or self.articles
        if not articles:
            logger.warning("Немає статей для експорту")
            return
        
        filepath = self.output_dir / filename
        
        data = {
            'total': len(articles),
            'timestamp': datetime.now().isoformat(),
            'articles': [article.to_dict() for article in articles]
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"✅ Експортовано {len(articles)} статей в {filepath}")
    
    def export_to_html(self, filename: str = "news.html", articles: List[NewsArticle] = None):
        """Експортує новини в HTML"""
        articles = articles or self.articles
        if not articles:
            logger.warning("Немає статей для експорту")
            return
        
        filepath = self.output_dir / filename
        
        html_content = """
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новини</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; }
        h1 { color: #333; }
        .article { border-bottom: 1px solid #ddd; padding: 20px 0; }
        .article h2 { margin: 0 0 10px 0; }
        .article a { color: #0066cc; text-decoration: none; }
        .article a:hover { text-decoration: underline; }
        .meta { color: #666; font-size: 0.9em; }
        .description { margin-top: 10px; color: #444; }
    </style>
</head>
<body>
    <h1>Новини</h1>
    <p>Зібрано статей: {total}</p>
""".format(total=len(articles))
        
        for article in articles:
            html_content += f"""
    <div class="article">
        <h2><a href="{article.url}" target="_blank">{article.title}</a></h2>
        <div class="meta">
            {article.source} | {article.category} | {article.date}
        </div>
        <div class="description">{article.description}</div>
    </div>
"""
        
        html_content += """
</body>
</html>
"""
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"✅ Експортовано {len(articles)} статей в {filepath}")
    
    def add_articles(self, articles: List[NewsArticle]):
        """Додає статті до колекції"""
        self.articles.extend(articles)
    
    def get_statistics(self) -> Dict:
        """Повертає статистику по зібраним статтям"""
        if not self.articles:
            return {}
        
        sources = {}
        categories = {}
        
        for article in self.articles:
            sources[article.source] = sources.get(article.source, 0) + 1
            if article.category:
                categories[article.category] = categories.get(article.category, 0) + 1
        
        return {
            'total': len(self.articles),
            'sources': sources,
            'categories': categories
        }


def main():
    """Головна функція"""
    parser = NewsParser()
    
    # Парсинг з різних джерел
    logger.info("=== Збір новин ===")
    
    # Hacker News
    hn_articles = parser.parse_hacker_news(max_articles=20)
    parser.add_articles(hn_articles)
    
    # BBC Technology
    bbc_articles = parser.parse_bbc_news(category="technology", max_articles=15)
    parser.add_articles(bbc_articles)
    
    # Статистика
    stats = parser.get_statistics()
    logger.info(f"\n📊 Статистика:")
    logger.info(f"Всього статей: {stats.get('total', 0)}")
    logger.info(f"Джерела: {stats.get('sources', {})}")
    
    # Експорт
    logger.info("\n=== Експорт даних ===")
    parser.export_to_csv("all_news.csv")
    parser.export_to_json("all_news.json")
    parser.export_to_html("all_news.html")
    
    # Фільтрація по ключовим словам
    keywords = ["AI", "Python", "technology", "software"]
    filtered = parser.filter_by_keywords(keywords)
    
    if filtered:
        logger.info(f"\n=== Фільтровані новини (ключові слова: {keywords}) ===")
        parser.export_to_csv("filtered_news.csv", filtered)
        parser.export_to_json("filtered_news.json", filtered)
    
    logger.info("\n✅ Парсинг завершено!")


if __name__ == "__main__":
    main()
